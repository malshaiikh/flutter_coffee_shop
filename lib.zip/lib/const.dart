import 'package:flutter/material.dart';

// background color for entire app
var backgroundColor = Colors.grey[300];